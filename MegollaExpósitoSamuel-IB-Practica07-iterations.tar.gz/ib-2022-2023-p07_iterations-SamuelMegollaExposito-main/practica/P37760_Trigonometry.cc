/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Samuel Megolla Expósito
  * @date Oct 17 noviembre
  * @brief El programa recibe un ángulo y proporciona el seno y el cose de dicho ángulo
  * @bug There are no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */

#include<iostream>
#include<iomanip>
#include<math.h>

double angle{0}, seno{0}, coseno{0};
const double factor = atan(1)/45;
using namespace std;


double Cos(double angle){
	coseno=cos(factor*angle);
return	coseno;
}

double Sen(double angle){
	seno=sin(factor*angle);
return seno;
}



int main(){

	while(cin>>angle){
	cout<<fixed<<setprecision(6)<<Sen(angle)<<" "<<Cos(angle)<<endl;
	}

return 0;
}
