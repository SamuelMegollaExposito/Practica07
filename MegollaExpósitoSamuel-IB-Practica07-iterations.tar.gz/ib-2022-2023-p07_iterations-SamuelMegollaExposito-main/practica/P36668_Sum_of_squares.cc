/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Samuel Megolla Expósito 
  * @date Oct 17 de noviembre
  * @brief El programa calcula la suma de las potencias la cantidad de números que se le indique
  * @bug There are no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */

#include<iostream>
#include<math.h>

using namespace std;
int sum= 0;
int number = 0;

int SumOfSquares(int number){

    for (int i = 1; i <= number; i++){
            sum += i*i;
    }

    return sum;

}

int main(){

	cin>>number;
	cout<<SumOfSquares(number)<<endl;
	


return 0;
}
