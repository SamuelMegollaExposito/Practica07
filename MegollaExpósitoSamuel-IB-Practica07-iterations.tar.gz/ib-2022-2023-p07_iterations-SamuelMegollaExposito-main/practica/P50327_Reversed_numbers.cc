/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Albert Einstein aeinstein@ull.edu.es
  * @date Oct 12 2022
  * @brief El programa recibira un numero natural positivo y devolvera como resultado el mismo escrito al reves
  * @bug There are no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */


#include <iostream>
using namespace std;

int main () {
	string number;
    cin >> number;
    for (int i = number.size()-1; i >= 0; i--)
     cout << number[i];
    cout << endl;
}
