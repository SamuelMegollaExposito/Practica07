#include<iostream>

using namespace std;
int sum{0};
int SumOfDigits(int number){
	
	while(number>0){
		sum=sum+number%10;
		number=number/10;
	}

return sum;
}






int main(){

	int number{0};

	cin>>number;
	cout<<SumOfDigits(number)<<endl;












return 0;
}
