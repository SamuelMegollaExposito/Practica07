#include<iostream>

using namespace std;

int main(){

	int number1{0},number2{1},number3{0};
	int contador;

	cin>>contador;
	cout<<number1<<endl<<number2<<endl;
	for(int i=2; i<contador; i++){
		number3=number1+number2;
		number1=number2;
		number2=number3;
		cout<<number3<<endl;
	}

return 0;
}
