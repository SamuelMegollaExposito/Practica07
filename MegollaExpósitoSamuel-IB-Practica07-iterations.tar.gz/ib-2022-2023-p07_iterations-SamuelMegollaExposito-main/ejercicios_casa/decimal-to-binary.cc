#include<iostream>

using namespace std;

int main(){

	int number{0};
	cin>>number;
	int binary;
	while(number>0){
		binary=number%2;
		cout<<binary;
		binary=0;
		number/=2;
	}
return 0;
}
