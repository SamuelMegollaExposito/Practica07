#include<iostream>

using namespace std;

int main(){

	int number1


















return 0;
}
